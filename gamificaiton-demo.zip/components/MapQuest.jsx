'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Map from './Map'
import { grantXP } from '@/app/actions'

export default function MapQuest() {
  const [status, setStatus] = useState('idle')
  const [msg, setMsg] = useState('Click anywhere on the map to generate a nearby quest.')
  const router = useRouter()

  async function handleMapClick({ lat, lng }) {
    setStatus('loading'); setMsg('Thinking…')
    const res = await fetch('/api/ai', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ lat, lng })
    })
    if (!res.ok) {
      const text = await res.text().catch(()=> 'Error')
      setStatus('error'); setMsg(text || `HTTP ${res.status}`); return
    }
    const data = await res.json()
    setStatus('ready'); setMsg(data.quest)
  }

  async function markDone() {
    await grantXP(50)
    setStatus('done')
    router.refresh()
  }

  return (
    <div>
      <Map onMapClick={handleMapClick} />
      <div className="card" style={{ marginTop:12 }}>
        <strong>Gemini Quest</strong>
        <p style={{ marginTop:8 }}>{msg}</p>
        {status === 'ready' && (
          <button onClick={markDone} style={{ padding:'8px 12px', border:'1px solid #e5e7eb', borderRadius:10 }}>
            Mark done (+50 XP)
          </button>
        )}
        {status === 'done' && <div style={{marginTop:8}}>✅ Completed! XP awarded.</div>}
        {status === 'error' && <div style={{marginTop:8,color:'#b91c1c'}}>Gemini error above—fix key or try again.</div>}
      </div>
    </div>
  )
}
