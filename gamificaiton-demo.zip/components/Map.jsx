"use client";
import { useEffect, useRef } from "react";

export default function Map({ onMapClick }) {
  const ref = useRef(null);
  const mapRef = useRef(null); // keep a handle to the map for cleanup

  useEffect(() => {
    let cleanup = () => {};

    (async () => {
      // Import Leaflet ONLY on the client
      const L = await import("leaflet");

      // Guard if the container is gone
      if (!ref.current) return;

      // Create map once
      const map = L.map(ref.current, { center: [45.44, 10.99], zoom: 13 });
      mapRef.current = map;

      // Base tiles
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap",
      }).addTo(map);

      // Layer for our markers
      const layer = L.layerGroup().addTo(map);

      // Click handler: bubble lat/lng to parent + show a small marker
      function handleClick(e) {
        const { lat, lng } = e.latlng;
        onMapClick?.({ lat, lng });
        L.circleMarker([lat, lng], { radius: 6, color: "#0ea5e9" })
          .bindPopup("Selected spot")
          .addTo(layer)
          .openPopup();
      }

      map.on("click", handleClick);

      // Cleanup
      cleanup = () => {
        try {
          map.off("click", handleClick);
          map.remove();
        } catch {}
      };
    })();

    return () => cleanup();
  }, [onMapClick]);

  return (
    <div
      ref={ref}
      style={{
        width: "100%",
        height: "70vh",
        borderRadius: 12,
        overflow: "hidden",
        border: "1px solid #e5e7eb",
        background: "#fff",
      }}
    />
  );
}
