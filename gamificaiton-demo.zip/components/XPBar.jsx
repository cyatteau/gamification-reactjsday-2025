'use client'
import { useMemo } from 'react'
export default function XPBar({ xp }) {
  const level = useMemo(() => Math.floor((xp||0) / 200) + 1, [xp])
  const pct = useMemo(() => Math.min(100, Math.round(((xp||0) % 200) / 2)), [xp])
  return (
    <div className="card">
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
        <strong>Level {level}</strong><span>{xp} XP</span>
      </div>
      <div style={{ height:10, background:'#f1f5f9', borderRadius:8, overflow:'hidden' }}>
        <div style={{ width:`${pct}%`, height:'100%', background:'linear-gradient(90deg,#7c3aed,#22d3ee)' }} />
      </div>
    </div>
  )
}
