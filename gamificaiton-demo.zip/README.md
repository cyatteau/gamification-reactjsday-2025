# Quest Map (Gemini) — Ultra-simple Live Demo

## What it shows
- **Server Components**: `app/page.jsx` + `app/(rsc)/ServerTip.jsx` (with `<Suspense>` so you can point at streaming UI)
- **Server Actions**: `grantXP(amount)` — press **Mark done** to add XP and refresh the XP bar
- **Gemini**: `/api/ai` requires `GEMINI_API_KEY` and returns `{"quest": string}` based on the map click (lat, lng)
- **React Compiler**: enabled in `next.config.mjs`
- **Client island**: `MapQuest` / `Map` handles clicks and calls the server API

## Run
```bash
npm i
echo "GEMINI_API_KEY=YOUR_KEY" > .env.local
npm run dev
# open http://localhost:3100
```

## Demo flow (~10 mins quick, or stretch to 25 with commentary)
1) Reload, show **Server Tip** loading then rendering (Suspense boundary).  
2) Click on the map → see “Thinking…” then a Gemini micro‑quest for that spot.  
3) Click **Mark done (+50 XP)** → XP bar increases via **Server Action**.  
4) Repeat with a different map location.  
5) Optional proof: Disable JS to show server sections still render; map won’t (client island).

## Notes
- The API intentionally errors if the key is missing or the model returns a wrong format. Fix the key and try again.
