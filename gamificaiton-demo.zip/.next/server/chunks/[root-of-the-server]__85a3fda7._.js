module.exports = [
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/.next-internal/server/app/api/ai/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/api/ai/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST,
    "dynamic",
    ()=>dynamic,
    "revalidate",
    ()=>revalidate,
    "runtime",
    ()=>runtime
]);
const runtime = "nodejs";
const dynamic = "force-dynamic";
const revalidate = 0;
function json(data, init = {}) {
    return new Response(JSON.stringify(data), {
        headers: {
            "Content-Type": "application/json",
            "Cache-Control": "no-store"
        },
        ...init
    });
}
async function POST(req) {
    const ts = Date.now();
    const body = await req.json().catch(()=>({}));
    const { lat, lng } = body || {};
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
        return new Response("GEMINI_API_KEY missing. Add it to .env.local and restart.", {
            status: 400
        });
    }
    if (typeof lat !== "number" || typeof lng !== "number") {
        return new Response("lat and lng are required numbers.", {
            status: 400
        });
    }
    const prompt = `Give ONE 15–25 word micro-quest a visitor can do near latitude ${lat}, longitude ${lng}.
Return strict JSON: {"quest":string}. Keep it concise, safe, and walkable.`;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`;
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            contents: [
                {
                    parts: [
                        {
                            text: prompt
                        }
                    ]
                }
            ],
            generationConfig: {
                responseMimeType: "application/json"
            }
        }),
        cache: "no-store"
    });
    if (!res.ok) {
        const text = await res.text().catch(()=>"");
        return new Response(`Gemini HTTP ${res.status}: ${text}`, {
            status: 502
        });
    }
    const data = await res.json().catch(()=>null);
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    let parsed = null;
    try {
        parsed = JSON.parse(text);
    } catch  {}
    if (!parsed || typeof parsed.quest !== "string") {
        return new Response("Gemini returned unexpected format.", {
            status: 502
        });
    }
    return json({
        ok: true,
        quest: parsed.quest,
        lat,
        lng,
        ts,
        source: "gemini"
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__85a3fda7._.js.map