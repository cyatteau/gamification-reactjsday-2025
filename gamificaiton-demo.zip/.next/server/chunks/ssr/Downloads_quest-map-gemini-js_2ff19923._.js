module.exports = [
"[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>XPBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
function XPBar({ xp }) {
    const level = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>Math.floor((xp || 0) / 200) + 1, [
        xp
    ]);
    const pct = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>Math.min(100, Math.round((xp || 0) % 200 / 2)), [
        xp
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "card",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'flex',
                    justifyContent: 'space-between',
                    marginBottom: 6
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                        children: [
                            "Level ",
                            level
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
                        lineNumber: 9,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            xp,
                            " XP"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
                        lineNumber: 9,
                        columnNumber: 39
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
                lineNumber: 8,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    height: 10,
                    background: '#f1f5f9',
                    borderRadius: 8,
                    overflow: 'hidden'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        width: `${pct}%`,
                        height: '100%',
                        background: 'linear-gradient(90deg,#7c3aed,#22d3ee)'
                    }
                }, void 0, false, {
                    fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
                lineNumber: 11,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}),
"[project]/Downloads/quest-map-gemini-js/components/Map.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Map
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/leaflet/dist/leaflet-src.js [app-ssr] (ecmascript)");
'use client';
;
;
;
function Map({ onMapClick }) {
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!ref.current) return;
        const map = __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["map"](ref.current, {
            center: [
                45.44,
                10.99
            ],
            zoom: 13
        });
        __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["tileLayer"]('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap'
        }).addTo(map);
        const layer = __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["layerGroup"]().addTo(map);
        map.on('click', (e)=>{
            const { lat, lng } = e.latlng;
            onMapClick?.({
                lat,
                lng
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["circleMarker"]([
                lat,
                lng
            ], {
                radius: 6,
                color: '#0ea5e9'
            }).bindPopup('Selected spot').addTo(layer).openPopup();
        });
        return ()=>map.remove();
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        style: {
            width: '100%',
            height: '70vh',
            borderRadius: 12,
            overflow: 'hidden',
            border: '1px solid #e5e7eb',
            background: '#fff'
        }
    }, void 0, false, {
        fileName: "[project]/Downloads/quest-map-gemini-js/components/Map.jsx",
        lineNumber: 21,
        columnNumber: 10
    }, this);
}
}),
"[project]/Downloads/quest-map-gemini-js/app/data:c25aba [app-ssr] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4061de0b9cda8e4d142f54648d8a9dfc8aae8080b1":"grantXP"},"Downloads/quest-map-gemini-js/app/actions.js",""] */ __turbopack_context__.s([
    "grantXP",
    ()=>grantXP
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var grantXP = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("4061de0b9cda8e4d142f54648d8a9dfc8aae8080b1", __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "grantXP"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcidcbmltcG9ydCB7IHJldmFsaWRhdGVUYWcgfSBmcm9tICduZXh0L2NhY2hlJ1xuaW1wb3J0IHsgYWRkWFAgfSBmcm9tICdAL2xpYi9kYidcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBncmFudFhQKGFtb3VudCA9IDUwKSB7XG4gIGF3YWl0IGFkZFhQKGFtb3VudClcbiAgcmV2YWxpZGF0ZVRhZygnZ2FtZScpXG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZTQUdzQiJ9
}),
"[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MapQuest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$Map$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/components/Map.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$data$3a$c25aba__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/app/data:c25aba [app-ssr] (ecmascript) <text/javascript>");
'use client';
;
;
;
;
;
function MapQuest() {
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('idle');
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('Click anywhere on the map to generate a nearby quest.');
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    async function handleMapClick({ lat, lng }) {
        setStatus('loading');
        setMsg('Thinking…');
        const res = await fetch('/api/ai', {
            method: 'POST',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify({
                lat,
                lng
            })
        });
        if (!res.ok) {
            const text = await res.text().catch(()=>'Error');
            setStatus('error');
            setMsg(text || `HTTP ${res.status}`);
            return;
        }
        const data = await res.json();
        setStatus('ready');
        setMsg(data.quest);
    }
    async function markDone() {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$data$3a$c25aba__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["grantXP"])(50);
        setStatus('done');
        router.refresh();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$Map$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                onMapClick: handleMapClick
            }, void 0, false, {
                fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "card",
                style: {
                    marginTop: 12
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                        children: "Gemini Quest"
                    }, void 0, false, {
                        fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            marginTop: 8
                        },
                        children: msg
                    }, void 0, false, {
                        fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this),
                    status === 'ready' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: markDone,
                        style: {
                            padding: '8px 12px',
                            border: '1px solid #e5e7eb',
                            borderRadius: 10
                        },
                        children: "Mark done (+50 XP)"
                    }, void 0, false, {
                        fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                        lineNumber: 40,
                        columnNumber: 11
                    }, this),
                    status === 'done' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginTop: 8
                        },
                        children: "✅ Completed! XP awarded."
                    }, void 0, false, {
                        fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                        lineNumber: 44,
                        columnNumber: 31
                    }, this),
                    status === 'error' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginTop: 8,
                            color: '#b91c1c'
                        },
                        children: "Gemini error above—fix key or try again."
                    }, void 0, false, {
                        fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                        lineNumber: 45,
                        columnNumber: 32
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                lineNumber: 36,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=Downloads_quest-map-gemini-js_2ff19923._.js.map