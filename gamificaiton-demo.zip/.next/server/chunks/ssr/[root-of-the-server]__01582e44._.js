module.exports = [
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/lib/db.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addXP",
    ()=>addXP,
    "getState",
    ()=>getState
]);
async function getState() {
    return structuredClone(state);
}
async function addXP(amount = 0) {
    state.xp = Math.max(0, state.xp + Number(amount || 0));
    return state;
}
let state = {
    xp: 0
};
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/actions.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"40ea3e5758e872971306c794442733f46c281f9ffa":"grantXP"},"",""] */ __turbopack_context__.s([
    "grantXP",
    ()=>grantXP
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/cache.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$lib$2f$db$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/lib/db.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
async function grantXP(amount = 50) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$lib$2f$db$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["addXP"])(amount);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidateTag"])('game');
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    grantXP
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(grantXP, "40ea3e5758e872971306c794442733f46c281f9ffa", null);
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/actions.js [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/actions.js [app-rsc] (ecmascript)");
;
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => \"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/actions.js [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "40ea3e5758e872971306c794442733f46c281f9ffa",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["grantXP"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f2e$next$2d$internal$2f$server$2f$app$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/.next-internal/server/app/page/actions.js { ACTIONS_MODULE0 => "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/actions.js [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$actions$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/actions.js [app-rsc] (ecmascript)");
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/layout.jsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/layout.jsx [app-rsc] (ecmascript)"));
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx <module evaluation>", "default");
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx", "default");
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$XPBar$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$XPBar$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$XPBar$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx <module evaluation>", "default");
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx", "default");
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$MapQuest$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$MapQuest$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$MapQuest$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/(rsc)/ServerTip.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ServerTip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
async function ServerTip() {
    await new Promise((r)=>setTimeout(r, 700));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "card",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                children: "Server Tip"
            }, void 0, false, {
                fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/(rsc)/ServerTip.jsx",
                lineNumber: 5,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    marginTop: 8
                },
                children: "Click the map to fetch a Gemini-generated micro‑quest near that spot."
            }, void 0, false, {
                fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/(rsc)/ServerTip.jsx",
                lineNumber: 6,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/(rsc)/ServerTip.jsx",
        lineNumber: 4,
        columnNumber: 5
    }, this);
}
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Page,
    "fetchCache",
    ()=>fetchCache,
    "revalidate",
    ()=>revalidate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$lib$2f$db$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/lib/db.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$XPBar$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/XPBar.jsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$MapQuest$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/components/MapQuest.jsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f28$rsc$292f$ServerTip$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/(rsc)/ServerTip.jsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
const revalidate = 0;
const fetchCache = 'default-no-store';
async function Page() {
    const state = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$lib$2f$db$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getState"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                style: {
                    display: 'grid',
                    gap: 12
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        children: "Quest Map (Gemini)"
                    }, void 0, false, {
                        fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$XPBar$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        xp: state.xp
                    }, void 0, false, {
                        fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Suspense"], {
                        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "card",
                            children: "Loading server tip…"
                        }, void 0, false, {
                            fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                            lineNumber: 17,
                            columnNumber: 29
                        }, void 0),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f28$rsc$292f$ServerTip$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                        lineNumber: 17,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive__$2d$__Esri$2f$Courtney_Tasks$2f$reactjsday2025$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$MapQuest$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                    lineNumber: 22,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
}),
"[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/OneDrive - Esri/Courtney_Tasks/reactjsday2025/quest-map-gemini-js/app/page.jsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__01582e44._.js.map