(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b2b7e_leaflet_dist_leaflet-src_79aae449.js",
  "static/chunks/OneDrive - Esri_Courtney_Tasks_reactjsday2025_quest-map-gemini-js_a72c7aa6._.js"
],
    source: "dynamic"
});
