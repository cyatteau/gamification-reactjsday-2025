(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b2b7e_leaflet_dist_leaflet-src_426c36e1.js"
],
    source: "dynamic"
});
