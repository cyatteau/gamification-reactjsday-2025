(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>XPBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
;
function XPBar(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "260a9db61f63dde23e29d243f773eeb0f5e747303000727ebfb95267d962dc82") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "260a9db61f63dde23e29d243f773eeb0f5e747303000727ebfb95267d962dc82";
    }
    const { xp } = t0;
    const level = Math.floor((xp || 0) / 200) + 1;
    const pct = Math.min(100, Math.round((xp || 0) % 200 / 2));
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            display: "flex",
            justifyContent: "space-between",
            marginBottom: 6
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== level) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: [
                "Level ",
                level
            ]
        }, void 0, true, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
            lineNumber: 31,
            columnNumber: 10
        }, this);
        $[2] = level;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    let t3;
    if ($[4] !== xp) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: [
                xp,
                " XP"
            ]
        }, void 0, true, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
            lineNumber: 39,
            columnNumber: 10
        }, this);
        $[4] = xp;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== t2 || $[7] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t1,
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
            lineNumber: 47,
            columnNumber: 10
        }, this);
        $[6] = t2;
        $[7] = t3;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            height: 10,
            background: "#f1f5f9",
            borderRadius: 8,
            overflow: "hidden"
        };
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    const t6 = "".concat(pct, "%");
    let t7;
    if ($[10] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t5,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    width: t6,
                    height: "100%",
                    background: "linear-gradient(90deg,#7c3aed,#22d3ee)"
                }
            }, void 0, false, {
                fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
                lineNumber: 69,
                columnNumber: 26
            }, this)
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
            lineNumber: 69,
            columnNumber: 10
        }, this);
        $[10] = t6;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] !== t4 || $[13] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "card",
            children: [
                t4,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/XPBar.jsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[12] = t4;
        $[13] = t7;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    return t8;
}
_c = XPBar;
var _c;
__turbopack_context__.k.register(_c, "XPBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Downloads/quest-map-gemini-js/components/Map.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Map
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/leaflet/dist/leaflet-src.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function Map(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "ba565d6daa4573721ea9f3160d20f50b3d99c12dd5be3d73ef2721d0bdaf971c") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "ba565d6daa4573721ea9f3160d20f50b3d99c12dd5be3d73ef2721d0bdaf971c";
    }
    const { onMapClick } = t0;
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t1;
    if ($[1] !== onMapClick) {
        t1 = ()=>{
            if (!ref.current) {
                return;
            }
            const map = __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["map"](ref.current, {
                center: [
                    45.44,
                    10.99
                ],
                zoom: 13
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tileLayer"]("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "&copy; OpenStreetMap"
            }).addTo(map);
            const layer = __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["layerGroup"]().addTo(map);
            map.on("click", (e)=>{
                const { lat, lng } = e.latlng;
                onMapClick === null || onMapClick === void 0 ? void 0 : onMapClick({
                    lat,
                    lng
                });
                __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$leaflet$2f$dist$2f$leaflet$2d$src$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["circleMarker"]([
                    lat,
                    lng
                ], {
                    radius: 6,
                    color: "#0ea5e9"
                }).bindPopup("Selected spot").addTo(layer).openPopup();
            });
            return ()=>map.remove();
        };
        $[1] = onMapClick;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = [];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: ref,
            style: {
                width: "100%",
                height: "70vh",
                borderRadius: 12,
                overflow: "hidden",
                border: "1px solid #e5e7eb",
                background: "#fff"
            }
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/Map.jsx",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    return t3;
}
_s(Map, "8uVE59eA/r6b92xF80p7sH8rXLk=");
_c = Map;
var _c;
__turbopack_context__.k.register(_c, "Map");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Downloads/quest-map-gemini-js/app/data:c25aba [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4061de0b9cda8e4d142f54648d8a9dfc8aae8080b1":"grantXP"},"Downloads/quest-map-gemini-js/app/actions.js",""] */ __turbopack_context__.s([
    "grantXP",
    ()=>grantXP
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var grantXP = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4061de0b9cda8e4d142f54648d8a9dfc8aae8080b1", __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "grantXP"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcidcbmltcG9ydCB7IHJldmFsaWRhdGVUYWcgfSBmcm9tICduZXh0L2NhY2hlJ1xuaW1wb3J0IHsgYWRkWFAgfSBmcm9tICdAL2xpYi9kYidcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBncmFudFhQKGFtb3VudCA9IDUwKSB7XG4gIGF3YWl0IGFkZFhQKGFtb3VudClcbiAgcmV2YWxpZGF0ZVRhZygnZ2FtZScpXG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZTQUdzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MapQuest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$Map$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/components/Map.jsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$data$3a$c25aba__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/Downloads/quest-map-gemini-js/app/data:c25aba [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function MapQuest() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(22);
    if ($[0] !== "e9c896127b55a8e8f6f00f9f1b772d9293a5b589736685e04fe358ecc5c005a4") {
        for(let $i = 0; $i < 22; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e9c896127b55a8e8f6f00f9f1b772d9293a5b589736685e04fe358ecc5c005a4";
    }
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Click anywhere on the map to generate a nearby quest.");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = async function handleMapClick(t1) {
            const { lat, lng } = t1;
            setStatus("loading");
            setMsg("Thinking\u2026");
            const res = await fetch("/api/ai", {
                method: "POST",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify({
                    lat,
                    lng
                })
            });
            if (!res.ok) {
                const text = await res.text().catch(_temp);
                setStatus("error");
                setMsg(text || "HTTP ".concat(res.status));
                return;
            }
            const data = await res.json();
            setStatus("ready");
            setMsg(data.quest);
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const handleMapClick = t0;
    let t1;
    if ($[2] !== router) {
        t1 = async function markDone() {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$app$2f$data$3a$c25aba__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["grantXP"])(50);
            setStatus("done");
            router.refresh();
        };
        $[2] = router;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const markDone = t1;
    let t2;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$components$2f$Map$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onMapClick: handleMapClick
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
            lineNumber: 68,
            columnNumber: 10
        }, this);
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    let t4;
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = {
            marginTop: 12
        };
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            children: "Gemini Quest"
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        t5 = {
            marginTop: 8
        };
        $[5] = t3;
        $[6] = t4;
        $[7] = t5;
    } else {
        t3 = $[5];
        t4 = $[6];
        t5 = $[7];
    }
    let t6;
    if ($[8] !== msg) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            style: t5,
            children: msg
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
            lineNumber: 94,
            columnNumber: 10
        }, this);
        $[8] = msg;
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== markDone || $[11] !== status) {
        t7 = status === "ready" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: markDone,
            style: {
                padding: "8px 12px",
                border: "1px solid #e5e7eb",
                borderRadius: 10
            },
            children: "Mark done (+50 XP)"
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
            lineNumber: 102,
            columnNumber: 32
        }, this);
        $[10] = markDone;
        $[11] = status;
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    let t8;
    if ($[13] !== status) {
        t8 = status === "done" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                marginTop: 8
            },
            children: "✅ Completed! XP awarded."
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
            lineNumber: 115,
            columnNumber: 31
        }, this);
        $[13] = status;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] !== status) {
        t9 = status === "error" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                marginTop: 8,
                color: "#b91c1c"
            },
            children: "Gemini error above—fix key or try again."
        }, void 0, false, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
            lineNumber: 125,
            columnNumber: 32
        }, this);
        $[15] = status;
        $[16] = t9;
    } else {
        t9 = $[16];
    }
    let t10;
    if ($[17] !== t6 || $[18] !== t7 || $[19] !== t8 || $[20] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "card",
                    style: t3,
                    children: [
                        t4,
                        t6,
                        t7,
                        t8,
                        t9
                    ]
                }, void 0, true, {
                    fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
                    lineNumber: 136,
                    columnNumber: 20
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Downloads/quest-map-gemini-js/components/MapQuest.jsx",
            lineNumber: 136,
            columnNumber: 11
        }, this);
        $[17] = t6;
        $[18] = t7;
        $[19] = t8;
        $[20] = t9;
        $[21] = t10;
    } else {
        t10 = $[21];
    }
    return t10;
}
_s(MapQuest, "PeNxohli3XjNzaRXifeiF2tDl+s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Downloads$2f$quest$2d$map$2d$gemini$2d$js$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = MapQuest;
function _temp() {
    return "Error";
}
var _c;
__turbopack_context__.k.register(_c, "MapQuest");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Downloads_quest-map-gemini-js_ecd3469b._.js.map