(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Downloads/quest-map-gemini-js/node_modules/leaflet/dist/leaflet-src.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/e2861_leaflet_dist_leaflet-src_0f4da549.js",
  "static/chunks/e2861_leaflet_dist_leaflet-src_45226d07.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Downloads/quest-map-gemini-js/node_modules/leaflet/dist/leaflet-src.js [app-client] (ecmascript)");
    });
});
}),
]);