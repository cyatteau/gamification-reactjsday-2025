(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8a592cf9._.js",
  "static/chunks/b2b7e_next_dist_compiled_react-dom_8a989716._.js",
  "static/chunks/b2b7e_next_dist_compiled_next-devtools_index_6279717b.js",
  "static/chunks/b2b7e_next_dist_compiled_5f3c5e15._.js",
  "static/chunks/b2b7e_next_dist_client_f2f9f9bb._.js",
  "static/chunks/b2b7e_next_dist_fbf6dcb5._.js",
  "static/chunks/b2b7e_@swc_helpers_cjs_b32aaa6b._.js"
],
    source: "entry"
});
