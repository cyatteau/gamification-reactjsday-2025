(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_leaflet_dist_leaflet-src_8b3c546f.js",
  "static/chunks/_68f88d5c._.js"
],
    source: "dynamic"
});
