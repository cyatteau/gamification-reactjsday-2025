(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/e2861_leaflet_dist_leaflet-src_b6b8c4f1.js",
  "static/chunks/Downloads_quest-map-gemini-js_bad198bb._.js"
],
    source: "dynamic"
});
