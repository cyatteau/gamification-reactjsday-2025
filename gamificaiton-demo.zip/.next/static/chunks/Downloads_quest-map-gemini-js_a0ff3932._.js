(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_26ce7c41._.js",
  "static/chunks/e2861_next_dist_compiled_react-dom_ed4bdba2._.js",
  "static/chunks/e2861_next_dist_compiled_next-devtools_index_a6cb6acb.js",
  "static/chunks/e2861_next_dist_compiled_530c7617._.js",
  "static/chunks/e2861_next_dist_client_c8adee75._.js",
  "static/chunks/e2861_next_dist_a762e383._.js",
  "static/chunks/e2861_@swc_helpers_cjs_fedf9b20._.js"
],
    source: "entry"
});
