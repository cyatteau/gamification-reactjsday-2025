(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/e2861_leaflet_dist_leaflet-src_0f4da549.js"
],
    source: "dynamic"
});
