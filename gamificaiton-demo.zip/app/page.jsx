import { Suspense } from 'react'
import { getState } from '@/lib/db'
import XPBar from '@/components/XPBar'
import MapQuest from '@/components/MapQuest'
import ServerTip from './(rsc)/ServerTip'

export const revalidate = 0
export const fetchCache = 'default-no-store'

export default async function Page() {
  const state = await getState()
  return (
    <main>
      <section style={{ display:'grid', gap:12 }}>
        <h1>Quest Map (Gemini)</h1>
        <XPBar xp={state.xp} />
        <Suspense fallback={<div className="card">Loading server tip…</div>}>
          <ServerTip />
        </Suspense>
      </section>
      <section>
        <MapQuest />
      </section>
    </main>
  )
}
