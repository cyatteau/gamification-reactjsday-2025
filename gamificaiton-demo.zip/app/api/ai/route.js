  export const runtime = "nodejs";
  export const dynamic = "force-dynamic";
  export const revalidate = 0;

  function json(data, init = {}) {
    return new Response(JSON.stringify(data), {
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      },
      ...init,
    });
  }

  export async function POST(req) {
    const ts = Date.now();
    const body = await req.json().catch(() => ({}));
    const { lat, lng } = body || {};
    const key = process.env.GEMINI_API_KEY;

    if (!key) {
      return new Response("GEMINI_API_KEY missing. Add it to .env.local and restart.", { status: 400 });
    }
    if (typeof lat !== "number" || typeof lng !== "number") {
      return new Response("lat and lng are required numbers.", { status: 400 });
    }

    const prompt = `Give ONE 15–25 word micro-quest a visitor can do near latitude ${lat}, longitude ${lng}.
Return strict JSON: {"quest":string}. Keep it concise, safe, and walkable.`;

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json" },
      }),
      cache: "no-store",
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return new Response(`Gemini HTTP ${res.status}: ${text}`, { status: 502 });
    }

    const data = await res.json().catch(() => null);
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    let parsed = null;
    try { parsed = JSON.parse(text); } catch {}

    if (!parsed || typeof parsed.quest !== "string") {
      return new Response("Gemini returned unexpected format.", { status: 502 });
    }

    return json({ ok: true, quest: parsed.quest, lat, lng, ts, source: "gemini" });
  }
