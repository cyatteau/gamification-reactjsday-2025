export const metadata = { title: "Quest Map (Gemini)", description: "RSC + Server Actions + Gemini" };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <style>{`
          :root{--border:#e5e7eb;--bg:#f7f9fc;--panel:#fff;--muted:#475569}
          *{box-sizing:border-box}
          body{margin:0;font-family:ui-sans-serif,system-ui,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:#0b1220}
          main{display:grid;grid-template-columns:minmax(320px,1fr) 2fr;gap:16px;padding:16px}
          h1{margin:0}
          .card{border:1px solid var(--border);border-radius:12px;padding:12px;background:var(--panel)}
          button{cursor:pointer}
        `}</style>
      </head>
      <body>{children}</body>
    </html>
  )
}
