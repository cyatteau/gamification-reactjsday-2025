'use server'
import { revalidateTag } from 'next/cache'
import { addXP } from '@/lib/db'
export async function grantXP(amount = 50) {
  await addXP(amount)
  revalidateTag('game')
}
