export default async function ServerTip() {
  await new Promise(r=>setTimeout(r, 700))
  return (
    <div className="card">
      <strong>Server Tip</strong>
      <p style={{marginTop:8}}>Click the map to fetch a Gemini-generated micro‑quest near that spot.</p>
    </div>
  )
}
